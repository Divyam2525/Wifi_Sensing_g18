import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.gridspec import GridSpec

# Set style for better-looking plots
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (15, 10)

# Load the data
df = pd.read_csv('raw_data.csv')

# Extract amplitude and phase columns
amp_cols = [col for col in df.columns if col.startswith('amp_')]
phase_cols = [col for col in df.columns if col.startswith('phase_')]

print("Dataset Overview:")
print(f"Total samples: {len(df)}")
print(f"Unique types: {df['type'].unique()}")
print(f"Unique days: {df['day'].unique()}")
print(f"Unique positions: {df['position'].unique()}")
print(f"Unique configurations: {df['configuration'].unique()}")
print("\n" + "="*50 + "\n")

# ============= PLOT 1: Average Amplitude Profile =============
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(15, 10))

# Calculate mean amplitude across all sensors
mean_amp = df[amp_cols].mean()
std_amp = df[amp_cols].std()
sensor_indices = range(len(amp_cols))

ax1.plot(sensor_indices, mean_amp.values, 'b-', linewidth=2, label='Mean')
ax1.fill_between(sensor_indices, 
                  mean_amp.values - std_amp.values, 
                  mean_amp.values + std_amp.values, 
                  alpha=0.3, label='±1 STD')
ax1.set_xlabel('Sensor Number', fontsize=12)
ax1.set_ylabel('Amplitude', fontsize=12)
ax1.set_title('Average Amplitude Profile Across All Sensors', fontsize=14, fontweight='bold')
ax1.legend()
ax1.grid(True, alpha=0.3)

# Calculate mean phase across all sensors
mean_phase = df[phase_cols].mean()
std_phase = df[phase_cols].std()

ax2.plot(sensor_indices, mean_phase.values, 'r-', linewidth=2, label='Mean')
ax2.fill_between(sensor_indices, 
                  mean_phase.values - std_phase.values, 
                  mean_phase.values + std_phase.values, 
                  alpha=0.3, color='red', label='±1 STD')
ax2.set_xlabel('Sensor Number', fontsize=12)
ax2.set_ylabel('Phase (radians)', fontsize=12)
ax2.set_title('Average Phase Profile Across All Sensors', fontsize=14, fontweight='bold')
ax2.legend()
ax2.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('01_sensor_profiles.png', dpi=300, bbox_inches='tight')
plt.show()

# ============= PLOT 2: Amplitude Distribution by Type =============
fig, axes = plt.subplots(2, 2, figsize=(15, 12))

# Box plot for amplitude by type
df['mean_amplitude'] = df[amp_cols].mean(axis=1)
df['mean_phase'] = df[phase_cols].mean(axis=1)
df['std_amplitude'] = df[amp_cols].std(axis=1)
df['std_phase'] = df[phase_cols].std(axis=1)

sns.boxplot(data=df, x='type', y='mean_amplitude', ax=axes[0, 0])
axes[0, 0].set_title('Mean Amplitude Distribution by Type', fontsize=12, fontweight='bold')
axes[0, 0].set_ylabel('Mean Amplitude', fontsize=10)

# Box plot for phase by type
sns.boxplot(data=df, x='type', y='mean_phase', ax=axes[0, 1])
axes[0, 1].set_title('Mean Phase Distribution by Type', fontsize=12, fontweight='bold')
axes[0, 1].set_ylabel('Mean Phase (radians)', fontsize=10)

# Violin plot for amplitude variability
sns.violinplot(data=df, x='type', y='std_amplitude', ax=axes[1, 0])
axes[1, 0].set_title('Amplitude Variability (STD) by Type', fontsize=12, fontweight='bold')
axes[1, 0].set_ylabel('Amplitude STD', fontsize=10)

# Violin plot for phase variability
sns.violinplot(data=df, x='type', y='std_phase', ax=axes[1, 1])
axes[1, 1].set_title('Phase Variability (STD) by Type', fontsize=12, fontweight='bold')
axes[1, 1].set_ylabel('Phase STD', fontsize=10)

plt.tight_layout()
plt.savefig('02_distribution_by_type.png', dpi=300, bbox_inches='tight')
plt.show()

# ============= PLOT 3: Heatmap of Amplitude Values =============
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(18, 8))

# Heatmap for amplitude
sns.heatmap(df[amp_cols].T, cmap='YlOrRd', ax=ax1, cbar_kws={'label': 'Amplitude'})
ax1.set_xlabel('Sample Index', fontsize=12)
ax1.set_ylabel('Sensor Number', fontsize=12)
ax1.set_title('Amplitude Heatmap Across All Sensors and Samples', fontsize=14, fontweight='bold')

# Heatmap for phase
sns.heatmap(df[phase_cols].T, cmap='coolwarm', ax=ax2, cbar_kws={'label': 'Phase (radians)'})
ax2.set_xlabel('Sample Index', fontsize=12)
ax2.set_ylabel('Sensor Number', fontsize=12)
ax2.set_title('Phase Heatmap Across All Sensors and Samples', fontsize=14, fontweight='bold')

plt.tight_layout()
plt.savefig('03_heatmaps.png', dpi=300, bbox_inches='tight')
plt.show()

# ============= PLOT 4: Configuration and Position Analysis =============
fig = plt.figure(figsize=(16, 10))
gs = GridSpec(2, 3, figure=fig)

# Configuration analysis
ax1 = fig.add_subplot(gs[0, 0])
config_counts = df['configuration'].value_counts()
ax1.bar(config_counts.index, config_counts.values, color='steelblue')
ax1.set_xlabel('Configuration', fontsize=10)
ax1.set_ylabel('Count', fontsize=10)
ax1.set_title('Sample Distribution by Configuration', fontsize=12, fontweight='bold')
ax1.tick_params(axis='x', rotation=45)

# Position analysis
ax2 = fig.add_subplot(gs[0, 1])
position_counts = df['position'].value_counts()
ax2.bar(position_counts.index, position_counts.values, color='coral')
ax2.set_xlabel('Position', fontsize=10)
ax2.set_ylabel('Count', fontsize=10)
ax2.set_title('Sample Distribution by Position', fontsize=12, fontweight='bold')
ax2.tick_params(axis='x', rotation=45)

# Day analysis
ax3 = fig.add_subplot(gs[0, 2])
day_counts = df['day'].value_counts().sort_index()
ax3.plot(day_counts.index, day_counts.values, marker='o', linewidth=2, markersize=8, color='green')
ax3.set_xlabel('Day', fontsize=10)
ax3.set_ylabel('Count', fontsize=10)
ax3.set_title('Sample Distribution Over Days', fontsize=12, fontweight='bold')
ax3.grid(True, alpha=0.3)

# Amplitude by Configuration
ax4 = fig.add_subplot(gs[1, 0])
sns.boxplot(data=df, x='configuration', y='mean_amplitude', ax=ax4)
ax4.set_title('Mean Amplitude by Configuration', fontsize=12, fontweight='bold')
ax4.tick_params(axis='x', rotation=45)

# Amplitude by Position
ax5 = fig.add_subplot(gs[1, 1])
sns.boxplot(data=df, x='position', y='mean_amplitude', ax=ax5)
ax5.set_title('Mean Amplitude by Position', fontsize=12, fontweight='bold')
ax5.tick_params(axis='x', rotation=45)

# Amplitude trend over days
ax6 = fig.add_subplot(gs[1, 2])
day_amplitude = df.groupby('day')['mean_amplitude'].agg(['mean', 'std'])
ax6.errorbar(day_amplitude.index, day_amplitude['mean'], 
             yerr=day_amplitude['std'], marker='o', linewidth=2, 
             markersize=8, capsize=5, color='purple')
ax6.set_xlabel('Day', fontsize=10)
ax6.set_ylabel('Mean Amplitude', fontsize=10)
ax6.set_title('Amplitude Trend Over Days', fontsize=12, fontweight='bold')
ax6.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('04_configuration_position_analysis.png', dpi=300, bbox_inches='tight')
plt.show()

# ============= PLOT 5: Correlation Analysis =============
fig, axes = plt.subplots(1, 2, figsize=(18, 7))

# Correlation between mean amplitude and mean phase
axes[0].scatter(df['mean_amplitude'], df['mean_phase'], alpha=0.6, c=df['day'], cmap='viridis')
axes[0].set_xlabel('Mean Amplitude', fontsize=12)
axes[0].set_ylabel('Mean Phase (radians)', fontsize=12)
axes[0].set_title('Correlation: Amplitude vs Phase', fontsize=14, fontweight='bold')
axes[0].grid(True, alpha=0.3)
cbar = plt.colorbar(axes[0].collections[0], ax=axes[0])
cbar.set_label('Day', fontsize=10)

# Amplitude vs Variability
axes[1].scatter(df['mean_amplitude'], df['std_amplitude'], alpha=0.6, 
                c=df['day'], cmap='plasma')
axes[1].set_xlabel('Mean Amplitude', fontsize=12)
axes[1].set_ylabel('Amplitude Variability (STD)', fontsize=12)
axes[1].set_title('Mean Amplitude vs Variability', fontsize=14, fontweight='bold')
axes[1].grid(True, alpha=0.3)
cbar = plt.colorbar(axes[1].collections[0], ax=axes[1])
cbar.set_label('Day', fontsize=10)

plt.tight_layout()
plt.savefig('05_correlation_analysis.png', dpi=300, bbox_inches='tight')
plt.show()

# ============= PLOT 6: Sensor Correlation Matrix =============
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 8))

# Select subset of sensors for readability (every 5th sensor)
amp_subset = [f'amp_{i}' for i in range(0, 52, 5)]
phase_subset = [f'phase_{i}' for i in range(0, 52, 5)]

# Amplitude correlation
amp_corr = df[amp_subset].corr()
sns.heatmap(amp_corr, annot=True, fmt='.2f', cmap='RdYlBu_r', 
            center=0, ax=ax1, square=True)
ax1.set_title('Amplitude Sensor Correlation Matrix (Subset)', fontsize=14, fontweight='bold')

# Phase correlation
phase_corr = df[phase_subset].corr()
sns.heatmap(phase_corr, annot=True, fmt='.2f', cmap='RdYlBu_r', 
            center=0, ax=ax2, square=True)
ax2.set_title('Phase Sensor Correlation Matrix (Subset)', fontsize=14, fontweight='bold')

plt.tight_layout()
plt.savefig('06_sensor_correlation.png', dpi=300, bbox_inches='tight')
plt.show()

# ============= PLOT 7: Statistical Summary =============
fig, axes = plt.subplots(2, 2, figsize=(15, 12))

# Distribution of mean amplitude
axes[0, 0].hist(df['mean_amplitude'], bins=30, color='skyblue', edgecolor='black', alpha=0.7)
axes[0, 0].axvline(df['mean_amplitude'].mean(), color='red', linestyle='--', 
                    linewidth=2, label=f"Mean: {df['mean_amplitude'].mean():.2f}")
axes[0, 0].set_xlabel('Mean Amplitude', fontsize=10)
axes[0, 0].set_ylabel('Frequency', fontsize=10)
axes[0, 0].set_title('Distribution of Mean Amplitude', fontsize=12, fontweight='bold')
axes[0, 0].legend()
axes[0, 0].grid(True, alpha=0.3)

# Distribution of mean phase
axes[0, 1].hist(df['mean_phase'], bins=30, color='lightcoral', edgecolor='black', alpha=0.7)
axes[0, 1].axvline(df['mean_phase'].mean(), color='blue', linestyle='--', 
                    linewidth=2, label=f"Mean: {df['mean_phase'].mean():.2f}")
axes[0, 1].set_xlabel('Mean Phase (radians)', fontsize=10)
axes[0, 1].set_ylabel('Frequency', fontsize=10)
axes[0, 1].set_title('Distribution of Mean Phase', fontsize=12, fontweight='bold')
axes[0, 1].legend()
axes[0, 1].grid(True, alpha=0.3)

# QQ plot for amplitude normality
from scipy import stats
stats.probplot(df['mean_amplitude'], dist="norm", plot=axes[1, 0])
axes[1, 0].set_title('Q-Q Plot: Mean Amplitude Normality', fontsize=12, fontweight='bold')
axes[1, 0].grid(True, alpha=0.3)

# QQ plot for phase normality
stats.probplot(df['mean_phase'], dist="norm", plot=axes[1, 1])
axes[1, 1].set_title('Q-Q Plot: Mean Phase Normality', fontsize=12, fontweight='bold')
axes[1, 1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('07_statistical_summary.png', dpi=300, bbox_inches='tight')
plt.show()

# ============= Statistical Summary Report =============
print("\n" + "="*50)
print("STATISTICAL SUMMARY REPORT")
print("="*50 + "\n")

print("Amplitude Statistics:")
print(f"  Mean: {df['mean_amplitude'].mean():.4f}")
print(f"  Median: {df['mean_amplitude'].median():.4f}")
print(f"  Std Dev: {df['mean_amplitude'].std():.4f}")
print(f"  Min: {df['mean_amplitude'].min():.4f}")
print(f"  Max: {df['mean_amplitude'].max():.4f}")

print("\nPhase Statistics:")
print(f"  Mean: {df['mean_phase'].mean():.4f} radians")
print(f"  Median: {df['mean_phase'].median():.4f} radians")
print(f"  Std Dev: {df['mean_phase'].std():.4f} radians")
print(f"  Min: {df['mean_phase'].min():.4f} radians")
print(f"  Max: {df['mean_phase'].max():.4f} radians")

print("\nCategorical Variable Distribution:")
print(f"\nType Distribution:\n{df['type'].value_counts()}")
print(f"\nConfiguration Distribution:\n{df['configuration'].value_counts()}")
print(f"\nPosition Distribution:\n{df['position'].value_counts()}")

print("\n" + "="*50)
print("All plots have been saved successfully!")
print("="*50)