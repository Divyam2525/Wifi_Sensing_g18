import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.gridspec import GridSpec
from scipy import signal
from scipy.fft import fft, fftfreq

# Set style for better-looking plots
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (15, 10)

# Load the data
df = pd.read_csv('raw_data.csv')

# Extract amplitude and phase columns (CSI data)
amp_cols = [col for col in df.columns if col.startswith('amp_')]
phase_cols = [col for col in df.columns if col.startswith('phase_')]
n_subcarriers = len(amp_cols)

print("="*60)
print("WiFi SENSING - CHANNEL STATE INFORMATION (CSI) ANALYSIS")
print("="*60)
print(f"\nDataset Overview:")
print(f"  Total samples: {len(df)}")
print(f"  Number of subcarriers: {n_subcarriers}")
print(f"  Types: {df['type'].unique()}")
print(f"  Days: {sorted(df['day'].unique())}")
print(f"  Positions: {df['position'].unique()}")
print(f"  Configurations: {df['configuration'].unique()}")
print("\n" + "="*60 + "\n")

# Calculate CSI-related features
df['mean_amplitude'] = df[amp_cols].mean(axis=1)
df['mean_phase'] = df[phase_cols].mean(axis=1)
df['amplitude_variance'] = df[amp_cols].var(axis=1)
df['phase_variance'] = df[phase_cols].var(axis=1)

# ============= PLOT 1: CSI Amplitude & Phase Patterns =============
print("Generating Plot 1: CSI Amplitude & Phase Patterns...")
fig = plt.figure(figsize=(16, 10))
gs = GridSpec(3, 2, figure=fig, hspace=0.3)

# Plot CSI amplitude for different samples
ax1 = fig.add_subplot(gs[0, :])
for idx in range(min(5, len(df))):
    ax1.plot(range(n_subcarriers), df[amp_cols].iloc[idx].values, 
             alpha=0.7, linewidth=2, label=f'Sample {idx+1}')
ax1.set_xlabel('Subcarrier Index', fontsize=12)
ax1.set_ylabel('Amplitude', fontsize=12)
ax1.set_title('CSI Amplitude Across Subcarriers (Multiple Samples)', 
              fontsize=14, fontweight='bold')
ax1.legend(loc='upper right')
ax1.grid(True, alpha=0.3)

# Plot CSI phase for different samples
ax2 = fig.add_subplot(gs[1, :])
for idx in range(min(5, len(df))):
    ax2.plot(range(n_subcarriers), df[phase_cols].iloc[idx].values, 
             alpha=0.7, linewidth=2, label=f'Sample {idx+1}')
ax2.set_xlabel('Subcarrier Index', fontsize=12)
ax2.set_ylabel('Phase (radians)', fontsize=12)
ax2.set_title('CSI Phase Across Subcarriers (Multiple Samples)', 
              fontsize=14, fontweight='bold')
ax2.legend(loc='upper right')
ax2.grid(True, alpha=0.3)

# Average CSI profile comparison by type
ax3 = fig.add_subplot(gs[2, 0])
for type_val in df['type'].unique():
    type_data = df[df['type'] == type_val]
    mean_amp = type_data[amp_cols].mean()
    ax3.plot(range(n_subcarriers), mean_amp.values, 
             linewidth=2.5, label=f'Type: {type_val}', marker='o', markersize=3)
ax3.set_xlabel('Subcarrier Index', fontsize=11)
ax3.set_ylabel('Average Amplitude', fontsize=11)
ax3.set_title('Average CSI Amplitude by Type', fontsize=12, fontweight='bold')
ax3.legend()
ax3.grid(True, alpha=0.3)

# Average phase profile comparison by type
ax4 = fig.add_subplot(gs[2, 1])
for type_val in df['type'].unique():
    type_data = df[df['type'] == type_val]
    mean_phase = type_data[phase_cols].mean()
    ax4.plot(range(n_subcarriers), mean_phase.values, 
             linewidth=2.5, label=f'Type: {type_val}', marker='o', markersize=3)
ax4.set_xlabel('Subcarrier Index', fontsize=11)
ax4.set_ylabel('Average Phase (radians)', fontsize=11)
ax4.set_title('Average CSI Phase by Type', fontsize=12, fontweight='bold')
ax4.legend()
ax4.grid(True, alpha=0.3)

plt.savefig('01_csi_patterns.png', dpi=300, bbox_inches='tight')
plt.show()

# ============= PLOT 2: CSI Heatmaps (Time-Frequency) =============
print("Generating Plot 2: CSI Heatmaps...")
fig, axes = plt.subplots(2, 2, figsize=(18, 12))

# Amplitude heatmap
im1 = axes[0, 0].imshow(df[amp_cols].T, aspect='auto', cmap='jet', 
                         interpolation='nearest')
axes[0, 0].set_xlabel('Time (Sample Index)', fontsize=11)
axes[0, 0].set_ylabel('Subcarrier Index', fontsize=11)
axes[0, 0].set_title('CSI Amplitude Heatmap (Time-Frequency)', 
                      fontsize=13, fontweight='bold')
plt.colorbar(im1, ax=axes[0, 0], label='Amplitude')

# Phase heatmap
im2 = axes[0, 1].imshow(df[phase_cols].T, aspect='auto', cmap='twilight', 
                         interpolation='nearest')
axes[0, 1].set_xlabel('Time (Sample Index)', fontsize=11)
axes[0, 1].set_ylabel('Subcarrier Index', fontsize=11)
axes[0, 1].set_title('CSI Phase Heatmap (Time-Frequency)', 
                      fontsize=13, fontweight='bold')
plt.colorbar(im2, ax=axes[0, 1], label='Phase (radians)')

# Amplitude variance across subcarriers
amp_var_subcarrier = df[amp_cols].var(axis=0)
axes[1, 0].bar(range(n_subcarriers), amp_var_subcarrier.values, 
               color='steelblue', alpha=0.7)
axes[1, 0].set_xlabel('Subcarrier Index', fontsize=11)
axes[1, 0].set_ylabel('Variance', fontsize=11)
axes[1, 0].set_title('Amplitude Variance Across Subcarriers', 
                      fontsize=13, fontweight='bold')
axes[1, 0].grid(True, alpha=0.3)

# Phase variance across subcarriers
phase_var_subcarrier = df[phase_cols].var(axis=0)
axes[1, 1].bar(range(n_subcarriers), phase_var_subcarrier.values, 
               color='coral', alpha=0.7)
axes[1, 1].set_xlabel('Subcarrier Index', fontsize=11)
axes[1, 1].set_ylabel('Variance', fontsize=11)
axes[1, 1].set_title('Phase Variance Across Subcarriers', 
                      fontsize=13, fontweight='bold')
axes[1, 1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('02_csi_heatmaps.png', dpi=300, bbox_inches='tight')
plt.show()

# ============= PLOT 3: Signal Strength & Quality Metrics =============
print("Generating Plot 3: Signal Strength & Quality Metrics...")
fig, axes = plt.subplots(2, 3, figsize=(18, 10))

# Mean amplitude distribution by type
sns.violinplot(data=df, x='type', y='mean_amplitude', ax=axes[0, 0], palette='Set2')
axes[0, 0].set_title('Signal Strength Distribution by Type', 
                      fontsize=12, fontweight='bold')
axes[0, 0].set_ylabel('Mean Amplitude', fontsize=10)
axes[0, 0].grid(True, alpha=0.3)

# Amplitude variance by position (multipath effect)
sns.boxplot(data=df, x='position', y='amplitude_variance', ax=axes[0, 1], palette='Set3')
axes[0, 1].set_title('Multipath Effect by Position', fontsize=12, fontweight='bold')
axes[0, 1].set_ylabel('Amplitude Variance', fontsize=10)
axes[0, 1].tick_params(axis='x', rotation=45)
axes[0, 1].grid(True, alpha=0.3)

# Signal stability over time
time_stability = df.groupby('day')['mean_amplitude'].agg(['mean', 'std'])
axes[0, 2].errorbar(time_stability.index, time_stability['mean'], 
                     yerr=time_stability['std'], marker='o', linewidth=2.5, 
                     markersize=8, capsize=5, color='green')
axes[0, 2].set_xlabel('Day', fontsize=10)
axes[0, 2].set_ylabel('Mean Amplitude', fontsize=10)
axes[0, 2].set_title('Signal Stability Over Time', fontsize=12, fontweight='bold')
axes[0, 2].grid(True, alpha=0.3)

# Phase variance by configuration
sns.boxplot(data=df, x='configuration', y='phase_variance', ax=axes[1, 0], palette='muted')
axes[1, 0].set_title('Phase Variance by Configuration', fontsize=12, fontweight='bold')
axes[1, 0].set_ylabel('Phase Variance', fontsize=10)
axes[1, 0].tick_params(axis='x', rotation=45)
axes[1, 0].grid(True, alpha=0.3)

# SNR proxy (amplitude to variance ratio)
df['snr_proxy'] = df['mean_amplitude'] / (df['amplitude_variance'] + 1e-6)
sns.violinplot(data=df, x='type', y='snr_proxy', ax=axes[1, 1], palette='pastel')
axes[1, 1].set_title('Signal Quality (SNR Proxy) by Type', fontsize=12, fontweight='bold')
axes[1, 1].set_ylabel('SNR Proxy', fontsize=10)
axes[1, 1].grid(True, alpha=0.3)

# Scatter: Amplitude vs Phase relationship
scatter = axes[1, 2].scatter(df['mean_amplitude'], df['mean_phase'], 
                              c=df['day'], cmap='viridis', alpha=0.6, s=50)
axes[1, 2].set_xlabel('Mean Amplitude', fontsize=10)
axes[1, 2].set_ylabel('Mean Phase (radians)', fontsize=10)
axes[1, 2].set_title('Amplitude-Phase Relationship', fontsize=12, fontweight='bold')
axes[1, 2].grid(True, alpha=0.3)
plt.colorbar(scatter, ax=axes[1, 2], label='Day')

plt.tight_layout()
plt.savefig('03_signal_quality_metrics.png', dpi=300, bbox_inches='tight')
plt.show()

# ============= PLOT 4: Doppler Effect & Motion Detection =============
print("Generating Plot 4: Doppler Effect & Motion Detection...")
fig, axes = plt.subplots(2, 2, figsize=(16, 12))

# Phase difference between consecutive subcarriers (frequency selectivity)
phase_diff = df[phase_cols].diff(axis=1).iloc[:, 1:]
mean_phase_diff = phase_diff.mean(axis=1)

axes[0, 0].hist(mean_phase_diff, bins=50, color='purple', alpha=0.7, edgecolor='black')
axes[0, 0].set_xlabel('Mean Phase Difference', fontsize=11)
axes[0, 0].set_ylabel('Frequency', fontsize=11)
axes[0, 0].set_title('Phase Difference Distribution (Frequency Selectivity)', 
                      fontsize=12, fontweight='bold')
axes[0, 0].grid(True, alpha=0.3)

# Temporal phase variation (motion indicator)
if len(df) > 1:
    temporal_phase_change = df[phase_cols].diff().abs().mean(axis=1)
    axes[0, 1].plot(temporal_phase_change.index, temporal_phase_change.values, 
                     linewidth=2, color='red', marker='o', markersize=4)
    axes[0, 1].set_xlabel('Sample Index', fontsize=11)
    axes[0, 1].set_ylabel('Phase Change', fontsize=11)
    axes[0, 1].set_title('Temporal Phase Variation (Motion Indicator)', 
                          fontsize=12, fontweight='bold')
    axes[0, 1].grid(True, alpha=0.3)

# Amplitude fading pattern
amp_change = df[amp_cols].diff().abs().mean(axis=1)
axes[1, 0].plot(amp_change.index, amp_change.values, 
                linewidth=2, color='blue', marker='s', markersize=4)
axes[1, 0].set_xlabel('Sample Index', fontsize=11)
axes[1, 0].set_ylabel('Amplitude Change', fontsize=11)
axes[1, 0].set_title('Amplitude Fading Pattern', fontsize=12, fontweight='bold')
axes[1, 0].grid(True, alpha=0.3)

# Phase unwrapping for first few subcarriers
for i in range(min(5, len(phase_cols))):
    phase_unwrapped = np.unwrap(df[phase_cols[i]].values)
    axes[1, 1].plot(phase_unwrapped, alpha=0.7, linewidth=2, 
                     label=f'Subcarrier {i}')
axes[1, 1].set_xlabel('Sample Index', fontsize=11)
axes[1, 1].set_ylabel('Unwrapped Phase (radians)', fontsize=11)
axes[1, 1].set_title('Phase Unwrapping (Doppler Analysis)', 
                      fontsize=12, fontweight='bold')
axes[1, 1].legend()
axes[1, 1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('04_doppler_motion_detection.png', dpi=300, bbox_inches='tight')
plt.show()

# ============= PLOT 5: Spatial Analysis (Position & Configuration) =============
print("Generating Plot 5: Spatial Analysis...")
fig, axes = plt.subplots(2, 2, figsize=(16, 12))

# 2D scatter: Position effect on signal
position_groups = df.groupby('position').agg({
    'mean_amplitude': 'mean',
    'mean_phase': 'mean',
    'amplitude_variance': 'mean'
}).reset_index()

axes[0, 0].scatter(position_groups['mean_amplitude'], 
                    position_groups['mean_phase'],
                    s=position_groups['amplitude_variance']*1000,
                    alpha=0.6, c=range(len(position_groups)), cmap='rainbow')
for i, pos in enumerate(position_groups['position']):
    axes[0, 0].annotate(pos, 
                         (position_groups['mean_amplitude'].iloc[i], 
                          position_groups['mean_phase'].iloc[i]),
                         fontsize=9, fontweight='bold')
axes[0, 0].set_xlabel('Mean Amplitude', fontsize=11)
axes[0, 0].set_ylabel('Mean Phase (radians)', fontsize=11)
axes[0, 0].set_title('Position-Based Signal Characteristics', 
                      fontsize=12, fontweight='bold')
axes[0, 0].grid(True, alpha=0.3)

# Configuration comparison
config_data = df.groupby('configuration')[['mean_amplitude', 'amplitude_variance']].mean()
x_pos = np.arange(len(config_data))
width = 0.35

axes[0, 1].bar(x_pos - width/2, config_data['mean_amplitude'], 
                width, label='Mean Amplitude', color='skyblue', alpha=0.8)
axes[0, 1].bar(x_pos + width/2, config_data['amplitude_variance']*10, 
                width, label='Variance (x10)', color='salmon', alpha=0.8)
axes[0, 1].set_xlabel('Configuration', fontsize=11)
axes[0, 1].set_ylabel('Value', fontsize=11)
axes[0, 1].set_title('Signal Metrics by Configuration', fontsize=12, fontweight='bold')
axes[0, 1].set_xticks(x_pos)
axes[0, 1].set_xticklabels(config_data.index, rotation=45)
axes[0, 1].legend()
axes[0, 1].grid(True, alpha=0.3, axis='y')

# Position vs Day interaction
pivot_data = df.pivot_table(values='mean_amplitude', 
                              index='position', 
                              columns='day', 
                              aggfunc='mean')
im = axes[1, 0].imshow(pivot_data.values, aspect='auto', cmap='YlOrRd')
axes[1, 0].set_xticks(range(len(pivot_data.columns)))
axes[1, 0].set_xticklabels(pivot_data.columns)
axes[1, 0].set_yticks(range(len(pivot_data.index)))
axes[1, 0].set_yticklabels(pivot_data.index)
axes[1, 0].set_xlabel('Day', fontsize=11)
axes[1, 0].set_ylabel('Position', fontsize=11)
axes[1, 0].set_title('Position-Day Signal Strength Heatmap', 
                      fontsize=12, fontweight='bold')
plt.colorbar(im, ax=axes[1, 0], label='Mean Amplitude')

# Configuration-Position combined analysis
combined = df.groupby(['configuration', 'position'])['mean_amplitude'].mean().unstack()
im2 = axes[1, 1].imshow(combined.values, aspect='auto', cmap='viridis')
axes[1, 1].set_xticks(range(len(combined.columns)))
axes[1, 1].set_xticklabels(combined.columns, rotation=45)
axes[1, 1].set_yticks(range(len(combined.index)))
axes[1, 1].set_yticklabels(combined.index)
axes[1, 1].set_xlabel('Position', fontsize=11)
axes[1, 1].set_ylabel('Configuration', fontsize=11)
axes[1, 1].set_title('Configuration-Position Signal Matrix', 
                      fontsize=12, fontweight='bold')
plt.colorbar(im2, ax=axes[1, 1], label='Mean Amplitude')

plt.tight_layout()
plt.savefig('05_spatial_analysis.png', dpi=300, bbox_inches='tight')
plt.show()

# ============= PLOT 6: Principal Component Analysis =============
print("Generating Plot 6: PCA Analysis...")
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

# Prepare data for PCA
X_amp = df[amp_cols].values
X_phase = df[phase_cols].values

# Standardize
scaler_amp = StandardScaler()
scaler_phase = StandardScaler()
X_amp_scaled = scaler_amp.fit_transform(X_amp)
X_phase_scaled = scaler_phase.fit_transform(X_phase)

# PCA
pca_amp = PCA()
pca_phase = PCA()
X_amp_pca = pca_amp.fit_transform(X_amp_scaled)
X_phase_pca = pca_phase.fit_transform(X_phase_scaled)

fig, axes = plt.subplots(2, 2, figsize=(16, 12))

# Explained variance (Amplitude)
cumsum_amp = np.cumsum(pca_amp.explained_variance_ratio_)
axes[0, 0].plot(range(1, len(cumsum_amp)+1), cumsum_amp, 
                 marker='o', linewidth=2.5, markersize=6, color='blue')
axes[0, 0].axhline(y=0.95, color='r', linestyle='--', label='95% Variance')
axes[0, 0].set_xlabel('Number of Components', fontsize=11)
axes[0, 0].set_ylabel('Cumulative Explained Variance', fontsize=11)
axes[0, 0].set_title('PCA: Amplitude Data', fontsize=12, fontweight='bold')
axes[0, 0].legend()
axes[0, 0].grid(True, alpha=0.3)

# Explained variance (Phase)
cumsum_phase = np.cumsum(pca_phase.explained_variance_ratio_)
axes[0, 1].plot(range(1, len(cumsum_phase)+1), cumsum_phase, 
                 marker='s', linewidth=2.5, markersize=6, color='red')
axes[0, 1].axhline(y=0.95, color='b', linestyle='--', label='95% Variance')
axes[0, 1].set_xlabel('Number of Components', fontsize=11)
axes[0, 1].set_ylabel('Cumulative Explained Variance', fontsize=11)
axes[0, 1].set_title('PCA: Phase Data', fontsize=12, fontweight='bold')
axes[0, 1].legend()
axes[0, 1].grid(True, alpha=0.3)

# 2D PCA visualization (Amplitude)
for type_val in df['type'].unique():
    mask = df['type'] == type_val
    axes[1, 0].scatter(X_amp_pca[mask, 0], X_amp_pca[mask, 1], 
                        alpha=0.6, s=80, label=f'Type: {type_val}')
axes[1, 0].set_xlabel(f'PC1 ({pca_amp.explained_variance_ratio_[0]:.2%})', fontsize=11)
axes[1, 0].set_ylabel(f'PC2 ({pca_amp.explained_variance_ratio_[1]:.2%})', fontsize=11)
axes[1, 0].set_title('PCA: Amplitude Feature Space', fontsize=12, fontweight='bold')
axes[1, 0].legend()
axes[1, 0].grid(True, alpha=0.3)

# 2D PCA visualization (Phase)
for type_val in df['type'].unique():
    mask = df['type'] == type_val
    axes[1, 1].scatter(X_phase_pca[mask, 0], X_phase_pca[mask, 1], 
                        alpha=0.6, s=80, label=f'Type: {type_val}')
axes[1, 1].set_xlabel(f'PC1 ({pca_phase.explained_variance_ratio_[0]:.2%})', fontsize=11)
axes[1, 1].set_ylabel(f'PC2 ({pca_phase.explained_variance_ratio_[1]:.2%})', fontsize=11)
axes[1, 1].set_title('PCA: Phase Feature Space', fontsize=12, fontweight='bold')
axes[1, 1].legend()
axes[1, 1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('06_pca_analysis.png', dpi=300, bbox_inches='tight')
plt.show()

# ============= PLOT 7: Statistical Summary for WiFi Sensing =============
print("Generating Plot 7: Statistical Summary...")
fig, axes = plt.subplots(2, 3, figsize=(18, 10))

# Channel impulse response estimate (via IFFT of amplitude)
sample_idx = 0
csi_amplitude = df[amp_cols].iloc[sample_idx].values
cir = np.fft.ifft(csi_amplitude)
axes[0, 0].stem(np.abs(cir)[:20], basefmt=' ')
axes[0, 0].set_xlabel('Delay Tap', fontsize=10)
axes[0, 0].set_ylabel('Magnitude', fontsize=10)
axes[0, 0].set_title('Channel Impulse Response (Sample)', fontsize=11, fontweight='bold')
axes[0, 0].grid(True, alpha=0.3)

# Subcarrier SNR estimation
mean_amp_per_subcarrier = df[amp_cols].mean()
std_amp_per_subcarrier = df[amp_cols].std()
snr_estimate = 20 * np.log10(mean_amp_per_subcarrier / (std_amp_per_subcarrier + 1e-6))
axes[0, 1].plot(range(n_subcarriers), snr_estimate.values, 
                 linewidth=2, color='green', marker='o', markersize=4)
axes[0, 1].set_xlabel('Subcarrier Index', fontsize=10)
axes[0, 1].set_ylabel('SNR (dB)', fontsize=10)
axes[0, 1].set_title('Estimated SNR per Subcarrier', fontsize=11, fontweight='bold')
axes[0, 1].grid(True, alpha=0.3)

# Phase linearity check
mean_phase_per_subcarrier = df[phase_cols].mean()
axes[0, 2].scatter(range(n_subcarriers), mean_phase_per_subcarrier.values, 
                    alpha=0.6, s=30, c=range(n_subcarriers), cmap='coolwarm')
axes[0, 2].set_xlabel('Subcarrier Index', fontsize=10)
axes[0, 2].set_ylabel('Mean Phase (radians)', fontsize=10)
axes[0, 2].set_title('Phase Linearity Across Subcarriers', fontsize=11, fontweight='bold')
axes[0, 2].grid(True, alpha=0.3)

# Type classification visualization
type_stats = df.groupby('type').agg({
    'mean_amplitude': ['mean', 'std'],
    'mean_phase': ['mean', 'std']
})

types = type_stats.index
x_pos = np.arange(len(types))
width = 0.35

axes[1, 0].bar(x_pos - width/2, type_stats['mean_amplitude']['mean'], 
                width, yerr=type_stats['mean_amplitude']['std'],
                label='Amplitude', color='blue', alpha=0.7, capsize=5)
axes[1, 0].bar(x_pos + width/2, np.abs(type_stats['mean_phase']['mean']), 
                width, yerr=type_stats['mean_phase']['std'],
                label='|Phase|', color='red', alpha=0.7, capsize=5)
axes[1, 0].set_xlabel('Type', fontsize=10)
axes[1, 0].set_ylabel('Value', fontsize=10)
axes[1, 0].set_title('Signal Characteristics by Type', fontsize=11, fontweight='bold')
axes[1, 0].set_xticks(x_pos)
axes[1, 0].set_xticklabels(types)
axes[1, 0].legend()
axes[1, 0].grid(True, alpha=0.3, axis='y')

# Temporal consistency
if len(df) >= 10:
    window_size = 5
    rolling_amp = df['mean_amplitude'].rolling(window=window_size).mean()
    rolling_std = df['mean_amplitude'].rolling(window=window_size).std()
    
    axes[1, 1].plot(rolling_amp.index, rolling_amp.values, 
                     linewidth=2, color='purple', label='Rolling Mean')
    axes[1, 1].fill_between(rolling_amp.index, 
                              rolling_amp - rolling_std, 
                              rolling_amp + rolling_std,
                              alpha=0.3, color='purple', label='±1 STD')
    axes[1, 1].set_xlabel('Sample Index', fontsize=10)
    axes[1, 1].set_ylabel('Mean Amplitude', fontsize=10)
    axes[1, 1].set_title('Temporal Signal Consistency', fontsize=11, fontweight='bold')
    axes[1, 1].legend()
    axes[1, 1].grid(True, alpha=0.3)

# Distance/Position effect summary
position_summary = df.groupby('position')['mean_amplitude'].agg(['mean', 'std', 'count'])
axes[1, 2].bar(range(len(position_summary)), position_summary['mean'], 
                yerr=position_summary['std'], capsize=5, 
                color='orange', alpha=0.7, edgecolor='black')
axes[1, 2].set_xlabel('Position', fontsize=10)
axes[1, 2].set_ylabel('Mean Amplitude', fontsize=10)
axes[1, 2].set_title('Signal Strength by Position', fontsize=11, fontweight='bold')
axes[1, 2].set_xticks(range(len(position_summary)))
axes[1, 2].set_xticklabels(position_summary.index, rotation=45)
axes[1, 2].grid(True, alpha=0.3, axis='y')

plt.tight_layout()
plt.savefig('07_wifi_sensing_summary.png', dpi=300, bbox_inches='tight')
plt.show()

# ============= WiFi Sensing Specific Statistics =============
print("\n" + "="*60)
print("WIFI SENSING - KEY PERFORMANCE INDICATORS")
print("="*60)

print("\n1. CHANNEL STATE INFORMATION (CSI) STATISTICS:")
print(f"   - Number of subcarriers: {n_subcarriers}")
print(f"   - Average amplitude: {df['mean_amplitude'].mean():.4f}")
print(f"   - Amplitude stability (CV): {df['mean_amplitude'].std()/df['mean_amplitude'].mean():.4f}")
print(f"   - Average phase: {df['mean_phase'].mean():.4f} rad")
print(f"   - Phase range: [{df['mean_phase'].min():.4f}, {df['mean_phase'].max():.4f}] rad")

print("\n2. MULTIPATH & FADING CHARACTERISTICS:")
print(f"   - Average amplitude variance: {df['amplitude_variance'].mean():.4f}")
print(f"   - Average phase variance: {df['phase_variance'].mean():.4f}")
print(f"   - Frequency selectivity index: {amp_var_subcarrier.mean():.4f}")

print("\n3. SPATIAL CHARACTERISTICS:")
print(f"   - Positions monitored: {df['position'].nunique()}")
print(f"   - Configurations tested: {df['configuration'].nunique()}")
position_range = df.groupby('position')['mean_amplitude'].mean()
print(f"   - Signal variation across positions: {position_range.std():.4f}")

print("\n4. TEMPORAL CHARACTERISTICS:")
print(f"   - Days of measurement: {df['day'].nunique()}")
print(f"   - Samples per day: {df.groupby('day').size().mean():.1f} (avg)")
if len(df) > 1:
    print(f"   - Temporal phase stability: {temporal_phase_change.mean():.4f}")

print("\n5. CLASSIFICATION POTENTIAL:")
for type_val in df['type'].unique():
    type_data = df[df['type'] == type_val]
    print(f"   - Type '{type_val}':")
    print(f"     * Samples: {len(type_data)}")
    print(f"     * Mean amplitude: {type_data['mean_amplitude'].mean():.4f}")
    print(f"     * Mean phase: {type_data['mean_phase'].mean():.4f} rad")

print("\n6. PCA DIMENSIONALITY REDUCTION:")
n_components_95_amp = np.argmax(cumsum_amp >= 0.95) + 1
n_components_95_phase = np.argmax(cumsum_phase >= 0.95) + 1
print(f"   - Components for 95% variance (Amplitude): {n_components_95_amp}/{n_subcarriers}")
print(f"   - Components for 95% variance (Phase): {n_components_95_phase}/{n_subcarriers}")
print(f"   - Dimensionality reduction (Amplitude): {(1-n_components_95_amp/n_subcarriers)*100:.1f}%")
print(f"   - Dimensionality reduction (Phase): {(1-n_components_95_phase/n_subcarriers)*100:.1f}%")

print("\n7. SIGNAL QUALITY METRICS:")
print(f"   - Average SNR proxy: {df['snr_proxy'].mean():.4f}")
print(f"   - SNR proxy range: [{df['snr_proxy'].min():.4f}, {df['snr_proxy'].max():.4f}]")
print(f"   - Estimated mean subcarrier SNR: {snr_estimate.mean():.2f} dB")

print("\n" + "="*60)
print("ANALYSIS COMPLETE!")
print("Generated 7 plot sets:")
print("  1. CSI Amplitude & Phase Patterns")
print("  2. CSI Heatmaps (Time-Frequency)")
print("  3. Signal Strength & Quality Metrics")
print("  4. Doppler Effect & Motion Detection")
print("  5. Spatial Analysis (Position & Configuration)")
print("  6. PCA Analysis")
print("  7. WiFi Sensing Statistical Summary")
print("="*60)